//variable
const courses = document.querySelector("#products")
shoppingCartContent = document.querySelector('#box-content')


//event listeners
eventListeners()
function eventListeners(){
    courses.addEventListener('click', buyCourse)

    //remove course from list
    shoppingCartContent.addEventListener('click', removeCourse)

}


//functions
function buyCourse(e){
    e.preventDefault()
    if(e.target.classList.contains('add-to-cart')){
        const course = e.target.parentElement
        getCourseInfo(course)
    }
}

    function getCourseInfo(course){
        const courseInfo = {
            image: course.querySelector('img').src,
            title: course.querySelector('h4').textContent,
            price: course.querySelector('.price').textContent,
            id: document.querySelectorAll('.all-info-card').getAttribute,
        }
        addToCart(courseInfo)
    }

    function addToCart(cInfo){
        let row = document.createElement('div')
        row.classList = 'row'
        // console.log(tr)
        // let row = document.querySelector('#box-content')
        // row.appendChild(tr)

        
        // //buld html template
        row.innerHTML = `   

            <div class="col-2">
                <img class="cart-image" src="${cInfo.image}">
            </div>
            <div class="col-6">
            <p class="cart-info">${cInfo.title}</p>
            </div>
            <div class="col-2">
            <p class="cart-price">${cInfo.price}</p>
            </div>
            <div class="col-2">
                <a class="remove-btn yesremove" href="#">X</a>
            </div>  
            <hr>
        `

        console.log(row)

        shoppingCartContent.appendChild(row)

        // shoppingCartContent.appendChild(row)
}

//remove Course from the list
function removeCourse(e){
    if(e.target.classList.contains('yesremove')){
        console.log(e.target.parentElement.parentElement.remove())
    }
}